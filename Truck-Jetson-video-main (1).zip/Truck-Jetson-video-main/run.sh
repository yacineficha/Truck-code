#!/bin/sh

sudo sh /home/ficha/run2.sh



