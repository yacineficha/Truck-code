  systemctl daemon-reload
  systemctl enable run_service.service
  systemctl start run_service.service